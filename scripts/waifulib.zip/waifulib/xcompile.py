# encoding: utf-8
# xcompile.py -- Modern NDK-Compatible Android Cross-Compilation Utility
# Copyright (C) 2018 a1batross
# Updated for NDK r16c-r25c (2024)

try:
    from fwgslib import get_flags_by_compiler
except:
    from waflib.extras.fwgslib import get_flags_by_compiler
from waflib import Logs, TaskGen
from waflib.Tools import c_config
from collections import OrderedDict
import os
import sys

ANDROID_NDK_ENVVARS = ['ANDROID_NDK_HOME', 'ANDROID_NDK']
ANDROID_NDK_SUPPORTED = [10, 16, 19, 20, 21, 22, 25]
ANDROID_NDK_HARDFP_MAX = 11
ANDROID_NDK_GCC_MAX = 17
ANDROID_64BIT_API_MIN = 21
ANDROID_NDK_API_MIN = {
    10: 3, 16: 16, 19: 16, 20: 16,
    21: 16, 22: 18, 25: 21
}

class Android:
    ctx = None
    arch = None
    toolchain = None
    api = None
    ndk_home = None
    ndk_rev = 0
    is_hardfloat = False
    clang = False

    def __init__(self, ctx, arch, toolchain, api):
        self.ctx = ctx
        self.api = api
        self.toolchain = toolchain
        self.arch = arch

        for i in ANDROID_NDK_ENVVARS:
            self.ndk_home = os.getenv(i)
            if self.ndk_home:
                break
        else:
            ctx.fatal(f'Set {" or ".join(ANDROID_NDK_ENVVARS)} environment variable!')

        # Detect NDK version
        source_prop = os.path.join(self.ndk_home, 'source.properties')
        if os.path.exists(source_prop):
            with open(source_prop) as f:
                for line in f:
                    if 'Pkg.Revision' in line:
                        rev = line.split('=')[1].strip()
                        self.ndk_rev = int(rev.split('.')[0])
                        break
            if self.ndk_rev not in ANDROID_NDK_SUPPORTED:
                Logs.warn(f'NDK revision {self.ndk_rev} may not be fully supported')
        else:
            self.ndk_rev = ANDROID_NDK_SUPPORTED[0]  # Default to oldest supported

        # Force Clang for modern NDKs
        if 'clang' in self.toolchain or self.ndk_rev > ANDROID_NDK_GCC_MAX:
            self.clang = True

        # Handle hardfloat ABI
        if self.arch == 'armeabi-v7a-hard' and self.ndk_rev <= ANDROID_NDK_HARDFP_MAX:
            self.arch = 'armeabi-v7a'
            self.is_hardfloat = True
        elif self.arch == 'armeabi-v7a-hard':
            ctx.fatal('NDK does not support hardfloat ABI')

        # Adjust API levels
        min_api = ANDROID_NDK_API_MIN.get(self.ndk_rev, ANDROID_64BIT_API_MIN)
        if self.api < min_api:
            self.api = min_api
            Logs.warn(f'API level set to {self.api} (min for NDK {self.ndk_rev})')

        if (self.is_arm64() or self.is_amd64()) and self.api < ANDROID_64BIT_API_MIN:
            self.api = ANDROID_64BIT_API_MIN
            Logs.warn(f'API level for 64-bit set to {self.api}')

    def is_host(self):
        return self.toolchain == 'host'

    def is_arm(self):
        return self.arch.startswith('armeabi')

    def is_x86(self):
        return self.arch == 'x86'

    def is_amd64(self):
        return self.arch == 'x86_64'

    def is_arm64(self):
        return self.arch == 'aarch64'

    def is_clang(self):
        return self.clang

    def is_hardfp(self):
        return self.is_hardfloat

    def ndk_triplet(self, llvm_toolchain=False, toolchain_folder=False):
        if self.is_x86():
            if toolchain_folder:
                return 'x86'
            return 'i686-linux-android'
        elif self.is_arm():
            if llvm_toolchain:
                return 'armv7a-linux-androideabi'
            return 'arm-linux-androideabi'
        elif self.is_amd64() and toolchain_folder:
            return 'x86_64'
        return f'{self.arch}-linux-android'

    def apk_arch(self):
        return 'arm64-v8a' if self.is_arm64() else self.arch

    def gen_host_toolchain(self):
        if self.is_host():
            return 'linux-x86_64'
            
        platform = sys.platform
        if platform.startswith('win') or platform.startswith('cygwin'):
            osname = 'windows'
        elif platform.startswith('darwin'):
            osname = 'darwin'
        elif platform.startswith('linux'):
            osname = 'linux'
        else:
            self.ctx.fatal('Unsupported host platform')
            
        arch = 'x86_64' if sys.maxsize > 2**32 else 'x86'
        return f'{osname}-{arch}'

    def gen_toolchain_path(self):
        """Modern toolchain path for NDK r19+"""
        host = self.gen_host_toolchain()
        base_path = os.path.join(self.ndk_home, 'toolchains', 'llvm', 'prebuilt', host)
        
        # Generate compiler prefix
        if self.is_arm():
            prefix = 'armv7a-linux-androideabi'
        elif self.is_x86():
            prefix = 'i686-linux-android'
        elif self.is_amd64():
            prefix = 'x86_64-linux-android'
        else:
            prefix = f'{self.arch}-linux-android'
            
        return os.path.join(base_path, 'bin', f'{prefix}{self.api}-')

    def cc(self):
        if self.is_host():
            return f'clang --target={self.ndk_triplet()}{self.api}'
        return self.gen_toolchain_path() + 'clang'

    def cxx(self):
        if self.is_host():
            return f'clang++ --target={self.ndk_triplet()}{self.api}'
        return self.gen_toolchain_path() + 'clang++'

    def strip(self):
        host = self.gen_host_toolchain()
        base_path = os.path.join(self.ndk_home, 'toolchains', 'llvm', 'prebuilt', host, 'bin')
        if self.is_host():
            return os.path.join(base_path, 'llvm-strip')
        
        prefix = {
            'arm': 'arm-linux-androideabi',
            'aarch64': 'aarch64-linux-android',
            'x86': 'i686-linux-android',
            'x86_64': 'x86_64-linux-android'
        }.get(self.arch, self.arch)
        
        return os.path.join(base_path, f'{prefix}-strip')

    def system_stl(self):
        return [
            os.path.join(self.ndk_home, 'sources', 'android', 'support', 'include')
        ]

    def cflags(self, cxx=False):
        # ========== 核心修复：解决头文件兼容性问题 ==========
        android_config_path = os.path.join(
            self.ndk_home, 
            'sources', 
            'android', 
            'support', 
            'include', 
            'android', 
            'config.h'
        )
        
        cflags = [
            '-DANDROID',
            '-D__ANDROID__',
            f'-D__ANDROID_API__={self.api}',
            '-stdlib=libc++',
            # 修复数学函数缺失问题
            '-D_LIBCPP_DISABLE_AVAILABILITY',  # 禁用C++可用性检查
            '-D__STDC_FORMAT_MACROS',          # 启用C99格式宏
            '-include', android_config_path,    # 强制包含Android配置头
            f'-I{os.path.join(self.ndk_home, "sources", "android", "support", "include")}'  # 显式包含路径
        ]
        
        cflags += [f'-I{i}' for i in self.system_stl()]

        # 架构优化（保留原有逻辑）
        if self.is_arm() and self.arch == 'armeabi-v7a':
            cflags += ['-march=armv7-a', '-mfloat-abi=softfp']
            if self.is_hardfp():
                cflags += [
                    '-D_NDK_MATH_NO_SOFTFP=1',
                    '-mfloat-abi=hard',
                    '-DLOAD_HARDFP',
                    '-DSOFTFP_LINK'
                ]
                if self.is_host():
                    for f in ['strtod', 'strtof', 'strtold']:
                        cflags += [f'-fno-builtin-{f}']
        elif self.is_x86():
            cflags += ['-march=atom', '-msse3', '-mfpmath=sse']
            
        return cflags

    def linkflags(self):
        linkflags = []
        linkflags += ['-fuse-ld=lld', '-Wl,--hash-style=both', '-Wl,--no-undefined']
        return linkflags

    def ldflags(self):
        ldflags = ['-no-canonical-prefixes', '-Qunused-arguments']
        
        # Link against libc++ and Android support
        ldflags += ['-lc++_static', '-lc++abi']
        if self.api < 21:
            ldflags += ['-landroid_support']
            
        return ldflags


def options(opt):
    android = opt.add_option_group('Android options')
    android.add_option('--android', action='store', dest='ANDROID_OPTS', default=None,
        help='Android build: --android=<arch>,<toolchain>,<api> (e.g., arm64-v8a,clang,21)')


def configure(conf):
    if not conf.options.ANDROID_OPTS:
        return
        
    values = conf.options.ANDROID_OPTS.split(',')
    if len(values) != 3:
        conf.fatal('Invalid --android parameter!')
        
    valid_archs = ['x86', 'x86_64', 'armeabi-v7a', 'aarch64']
    if values[0] not in valid_archs:
        conf.fatal(f'Unsupported arch: {values[0]}. Valid: {", ".join(valid_archs)}')

    conf.android = android = Android(conf, values[0], values[1], int(values[2]))
    
    # Set compiler paths
    conf.environ['CC'] = android.cc()
    conf.environ['CXX'] = android.cxx()
    conf.environ['STRIP'] = android.strip()
    
    # Set flags
    conf.env.CFLAGS += android.cflags()
    conf.env.CXXFLAGS += android.cflags(True)
    conf.env.LINKFLAGS += android.linkflags()
    conf.env.LDFLAGS += android.ldflags()
    
    # libc++ setup
    stl_path = os.path.join(android.ndk_home, 'sources', 'cxx-stl', 'llvm-libc++')
    conf.env.INCLUDES += [
        os.path.join(stl_path, 'include'),
        os.path.join(android.ndk_home, 'sources', 'android', 'support', 'include')
    ]
    
    # Architecture-specific lib paths
    lib_path = os.path.join(stl_path, 'libs', android.apk_arch())
    if os.path.exists(lib_path):
        conf.env.STLIBPATH += [lib_path]
    
    # System libraries
    conf.env.HAVE_M = True
    conf.env.LIB_M = ['m']
    
    # Android target config
    conf.env.PREFIX += f'/lib/{android.apk_arch()}'
    conf.env.DEST_OS2 = 'android'
    
    # Log configuration
    conf.msg('Android NDK', f'{android.ndk_home} (r{android.ndk_rev})')
    conf.msg('Target arch', android.arch)
    conf.msg('API level', android.api)
    conf.msg('C++ stdlib', 'libc++')

    # Android OS macros
    MACRO_TO_DESTOS = OrderedDict({ '__ANDROID__' : 'android' })
    for k in c_config.MACRO_TO_DESTOS:
        MACRO_TO_DESTOS[k] = c_config.MACRO_TO_DESTOS[k]
    c_config.MACRO_TO_DESTOS = MACRO_TO_DESTOS


def post_compiler_configure(conf):
    conf.msg('Target OS', conf.env.DEST_OS)
    conf.msg('Target CPU', conf.env.DEST_CPU)
    conf.msg('Target binfmt', conf.env.DEST_BINFMT)


# ========== 修复递归错误 ==========
from waflib.Tools import compiler_cxx, compiler_c

_original_compiler_cxx_configure = compiler_cxx.configure
_original_compiler_c_configure = compiler_c.configure

def patched_compiler_cxx_configure(conf):
    _original_compiler_cxx_configure(conf)
    post_compiler_configure(conf)

def patched_compiler_c_configure(conf):
    _original_compiler_c_configure(conf)
    post_compiler_configure(conf)

# 安全覆盖原始函数
compiler_cxx.configure = patched_compiler_cxx_configure
compiler_c.configure = patched_compiler_c_configure


@TaskGen.feature('cshlib', 'cxxshlib', 'dshlib', 'fcshlib', 'vnum')
@TaskGen.after_method('apply_link', 'propagate_uselib_vars')
@TaskGen.before_method('apply_vnum')
def apply_android_soname(self):
    if self.env.DEST_OS != 'android':
        return
        
    setattr(self, 'vnum', None)
    link = self.link_task
    node = link.outputs[0]
    v = self.env.SONAME_ST % node.name
    self.env.append_value('LINKFLAGS', v.split())
